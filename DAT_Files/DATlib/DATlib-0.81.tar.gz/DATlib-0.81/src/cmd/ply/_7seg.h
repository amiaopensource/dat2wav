struct ixbm {
	int		height,width;
	unsigned char	*bits;
};
void disp7seg(struct ixbm *xb,int *px,int *py,int mask);
void disp7dp(struct ixbm *xb,int *x,int *y);
void disp7segnr(struct ixbm *xb,int *x,int *y,int nr,int res);
void disp7letter(struct ixbm *xb,int *x,int *y,int letter);
void init_xb(struct ixbm *xb,int width,int height);
