/* Contains the version number of DATLIB */

#define DATLIB_VERSION	"0.5"
