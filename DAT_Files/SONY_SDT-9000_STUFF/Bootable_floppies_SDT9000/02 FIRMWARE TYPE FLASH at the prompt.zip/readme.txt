Sony SDT-9000 SGI audio firmware 12.2 - Thanks to everyone who helped to reconstitute it.
(Mr X for the dump, zozo for the flash utility, dean for encrytion/decryption, Max and other for testing)


You need to use a DOS boot disk with your DOS SCSI ASPI drivers Loaded.

- Extract the 4 files on a second floppy and type FLASH.


Important note!! We recommand you to disconnect every SCSI devices (excepted the Sony 9000) 
before flashing to avoid any possible problem. 
This firmware could create some incompatibilities with some backup software. It is only recommended for audio use! 


Enjoy :) playing DAT audio with Vdat or DAT2wav or any other DAT audio player




