/*
 * DATlib   Copyright (c) 1995-1996 Marcus Meissner &
 *          Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *          All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Marcus Meissner
 *    at the Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *
 * 4. The name of the University or the author may not be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* $Id: playtrack.c,v 1.5 1997/12/15 12:32:10 msmeissn Exp $
 *
 * $Log: playtrack.c,v $
 * Revision 1.5  1997/12/15 12:32:10  msmeissn
 * *** empty log message ***
 *
 * Revision 1.4  1997/12/14 22:36:24  msmeissn
 * enhanced noabs logic
 *
 * Revision 1.3  1997/09/30 14:35:36  msmeissn
 * *** empty log message ***
 *
 * Revision 1.2  1997/08/06 14:54:01  msmeissn
 * some cleanups, options
 *
 * Revision 1.1  1997/03/16 20:27:25  msmeissn
 * Initial revision
 *
 *
 * playtrack.c: Simple demo program to write a DAT-audiotrack to stdout
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/fcntl.h>

#include "dataudiolib.h"
#include "xaudio.h"
#include "audio_filehdr.h"

void
usage() {
	fprintf(stderr,
"Usage:\n"
"	playtrack > file.au\n"
"Options:\n"
"	-r or --raw	write raw samples only\n"
"	--noabs 	don't check for absolute time\n"
"	--noprognr 	don't check for program number\n"
"       -i or --ignore  ignore rate changes\n"
"	-f <device>	use device <device> instead of $TAPE or "DEFAULTAUDIOTAPE"\n"
	);
	exit(1);
}

int
main(int argc,char **argv) {
	int	fd;
	char	*tape;
	unsigned char buf[2000];
	int	res;
	int	written;
	int	lastsamplerate=0,samplerate,xprognr,prognr=0;
	struct	da_time atime;
	int	absfound=0,noabs,noprognr,i,raw,headerwritten,absmissing=0,ignore=0;
	Audio_filehdr	fhdr;

	tape=NULL;
	raw=noabs=noprognr=0;
	for (i=1;i<argc;i++) {
		if (!strcmp(argv[i],"--noabs")) {
			noabs=1;
			continue;
		}
		if (!strcmp(argv[i],"--noprognr")) {
			noprognr=1;
			continue;
		}
		if (	!strcmp(argv[i],"--ignore") ||
			!strcmp(argv[i],"-i")
		) {
			ignore=1;
			continue;
		}
		if (	!strcmp(argv[i],"--raw") ||
			!strcmp(argv[i],"-r")
		) {
			raw=1;
			continue;
		}
		if (!strcmp(argv[i],"-f") && (i<argc-1)) {
			tape=argv[i+1];
			i++;
			continue;
		}
		usage();
		break;
	}
	if (!tape) tape=getenv("TAPE");
	if (!tape) tape=DEFAULTAUDIOTAPE;

	fd=da_open(tape,O_RDONLY);
	if (fd==-1) {
		fprintf(stderr,"%s:could not open ",argv[0]);
		perror(tape);
		exit(1);
	}
	written=0;
	headerwritten=0;
	while (1) {
		int	curleft;

		curleft=0;
		while (curleft<2000) {
			res=da_read(fd,buf+curleft,2000-curleft);
			if (res==-1) {
				perror("da_read");
				break;
			}
			curleft+=res;
		}
		if (curleft<2000) /* failed read */
			break;
		if (!lastsamplerate)
			da_control(fd,DA_GET_SAMPLERATE,(long)&lastsamplerate);
		if (!noprognr && !prognr) {
			if (-1==da_control(fd,DA_GET_PROGNR,(long)&prognr))
				perror("da_get_prognr");
		}
		if (!raw && !headerwritten) {
			int	channels;
			/* time to dump the header */
			if (-1==da_control(fd,DA_GET_SAMPLERATE,(long)&samplerate)) {
				perror("da_control DA_GET_SAMPLERATE");
				break;
			}
			fhdr.sample_rate=samplerate;
			if (-1==da_control(fd,DA_GET_CHANNELS,(long)&channels)) {
				perror("da_control DA_GET_CHANNELS");
				break;
			}
			fhdr.channels	= channels;
			fhdr.magic	= AUDIO_FILE_MAGIC;
			fhdr.encoding	= AUDIO_FILE_ENCODING_LINEAR_16;
			fhdr.hdr_size	= sizeof(fhdr);
			fhdr.data_size	= ~0;
			curleft=0;
			while (curleft<sizeof(fhdr)) {
				res=write(fileno(stdout),((char*)(&fhdr))+curleft,sizeof(fhdr)-curleft);
				if (res==-1) {
					perror("write header");
					break;
				}
				curleft+=res;
			}
			if (res==-1)
				break;
			headerwritten=1;
		}
		if (!noprognr) {
			if (-1==da_control(fd,DA_GET_PROGNR,(long)&xprognr)) {
				perror("da_get_prognr");
				break;
			}
			if (prognr!=xprognr) {
				fprintf(stderr,"Programnumber for this track was: %d, new programnumber is %d.\n",prognr,xprognr);
				break; /* fini */
			}
			prognr=xprognr;
		}
		if (!noabs) {
			if (-1==da_control(fd,DA_GET_ABSTIME,(long)&atime)) {
				absmissing++;
				if (absmissing>20) {
					fprintf(stderr,"No absolute time on tape, switched off detection.\n");
					noabs=1;
				}
			} else {
				absfound=1;
				absmissing=0;
			}
		}
		samplerate=0;
		da_control(fd,DA_GET_SAMPLERATE,(long)&samplerate);
		if (samplerate!=lastsamplerate) {
		  fprintf(stderr,"samplerate switched from %d to %d\n",lastsamplerate,samplerate);
		  lastsamplerate=samplerate;
                  if(!ignore){
			break;
		  }
                }
		curleft=0;
		while (curleft<2000) {
			res=write(fileno(stdout),buf+curleft,2000-curleft);
			if (res==-1) {
				perror("write");
				break;
			}
			curleft+=res;
			written+=res;
		}
	}
	fprintf(stderr,"Written: %d bytes\n",written);
	/*da_close(fd);*/
	return 0;
}
