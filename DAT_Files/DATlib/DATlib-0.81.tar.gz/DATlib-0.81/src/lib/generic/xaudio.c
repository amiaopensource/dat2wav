/*
 * DATlib   Copyright (c) 1995-1996 Marcus Meissner &
 *          Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *          All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Marcus Meissner
 *    at the Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *
 * 4. The name of the University or the author may not be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* $Id: xaudio.c,v 1.2 1997/06/02 18:39:53 msmeissn Exp $
 *
 * $Log: xaudio.c,v $
 * Revision 1.2  1997/06/02 18:39:53  msmeissn
 * malloc.h -> stdlib.h
 * .,
 *
 * Revision 1.1  1997/03/16 20:29:10  msmeissn
 * Initial revision
 *
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/fcntl.h> /* for O_WRONLY */
#ifdef linux
#include <sys/soundcard.h>
#endif
#ifdef sun
#include <sys/audioio.h>
#endif

/* same for both of sun and linux */
int
audio_open(int mode) {
	int	nonblock,fd;
	FILE	*term;

	switch (mode) {
	case O_RDONLY:
		term=stdin;
		break;
	case O_WRONLY:
		term=stdout;
		break;
	default:
		term=stdout;
		break;
	}
	fd=fileno(term);
	if (isatty(fd)) {
		fd=open("/dev/audio",mode);
		if (fd==-1)
			return -1;
	}
#ifdef linux
	nonblock=1;
	if (-1==ioctl(fd,SNDCTL_DSP_NONBLOCK,&nonblock)) {
		perror("set nonblock");
	}
#endif
	return fd;
}

#ifdef linux
/* linux, or at least my GUS needs buffering. *SIGH* */
static unsigned char	*outbuf=NULL;
int	outbuflen=0;

void
audio_change_attribs(int afd,int speed,int bits,int stereo) {
	int	nonblock;

	if (-1==ioctl(afd,SNDCTL_DSP_SPEED,&speed)) {
		perror("set speed");
	}
	if (-1==ioctl(afd,SNDCTL_DSP_STEREO,&stereo)) {
		perror("set stereo");
	}
	/* AFMT_S16_LE is 16, yes. */
	if (-1==ioctl(afd,SNDCTL_DSP_SETFMT,&bits)) {
		perror("set format 16bit le");
	}
}

int
audio_write(int afd, unsigned char *buf, int howmuch) {
	int	res;

	res=outbuflen;
	if (outbuflen) {
		res=write(afd,outbuf,outbuflen);
		if (res==-1) {
			perror("write");
			return -1;
		}
		memmove(outbuf,outbuf+res,outbuflen-res);
		outbuflen-=res;

	}
	res=write(afd,buf,howmuch);
	if (res==-1) {
		perror("write");
		return -1;
	}
	outbuf = realloc(outbuf,outbuflen+howmuch-res);
	memmove(outbuf+outbuflen,buf+res,howmuch-res);
	outbuflen+= howmuch-res;
	return howmuch;
}
int
audio_read(int afd, unsigned char *buf, int howmuch) {
	return read(afd,buf,howmuch);
}


#endif

#ifdef sun
void
audio_change_attribs(int afd,int speed,int bits,int stereo) {
	audio_info_t	ainfo;

	AUDIO_INITINFO(&ainfo);
	if (-1==ioctl(afd,AUDIO_GETINFO,&ainfo)) {
		perror("ioctl AUDIO_GETINFO");
	}
#define AT	(ainfo.play)
	AT.sample_rate	= speed;
	AT.channels	= stereo+1;
	AT.precision	= bits;
	AT.encoding	= 3; /* 16 bit linear */
	if (-1==ioctl(afd,AUDIO_SETINFO,ainfo)) {
		perror("ioctl AUDIO_SETINFO");
	}
}

int
audio_write(int afd, unsigned char *buf, int howmuch) {
	return write(afd,buf,howmuch);
}
int
audio_read(int afd, unsigned char *buf, int howmuch) {
	return read(afd,buf,howmuch);
}
#endif

void
audio_close(int afd) {
	close(afd);
#ifdef linux
	if (outbuf) {
		free(outbuf);
		outbuf=NULL;
	}
#endif
}
