/* helper object for converting BCD 2 Long and back */
int
bcd2l(int x) {
	return (((x)&0xf)+(((x)&0xf0)>>4)*10+(((x)&0xf00)>>8)*100+(((x)&0xf000)>>12)*1000);
}

int
l2bcd(int x) {
	return (((x)%10)+(((x)/10)%10)*0x10+(((x)/100)%10)*0x100+(((x)/1000)%10)*0x1000);
}

int
_bcdinc(int x) { return l2bcd(bcd2l(x)+1); }
