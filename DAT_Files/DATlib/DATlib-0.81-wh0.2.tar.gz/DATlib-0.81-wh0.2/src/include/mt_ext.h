/*
 * DATlib   Copyright (c) 1995-1996 Marcus Meissner &
 *          Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *          All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Marcus Meissner
 *    at the Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *
 * 4. The name of the University or the author may not be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* the additional Solaris 2.x types start with major nr. 0x6D ',' as in Marcus*/

#ifndef SCMD_RECEIVE_DIAGNOSTICS
#define SCMD_RECEIVE_DIAGNOSTICS	0x1c
#endif
#ifndef SCMD_LOG_SENSE
#define SCMD_LOG_SENSE		LOG_SENSE_CMD
#endif
#ifndef SCMD_LOCATE
#define SCMD_LOCATE		0x2B
#endif
#ifndef SCMD_READ_POSITION
#define SCMD_READ_POSITION	0x34
#endif

/* head of a memory block... we hand this struct to the MTIOQLPAGE ioctl 
 * with len set.
 */
struct	mt_logpage {
	int			len;
	unsigned	char	nr;
	unsigned	char	buf[1];
};

/* dito modepage */
struct	mt_modepage {
	int			len;
	unsigned	char	nr;
	unsigned	char	buf[1];
};
/* nearly dito inquiry */
struct	mt_inquiry {
	int			len;
	unsigned	char	buf[1];
};

/* has to be ORed to size... size is maximal 65535 */
#define MTSIZEBYTES	0x00000	/* byte size for create part */
#define MTSIZEKBYTES	0x10000	/* kbyte size for create part */
#define MTSIZEMBYTES	0x20000	/* mbyte size for create part */
#define MTSIZEKINDMASK	0x30000	/* byte size mask for create part */
#define MTSIZESIZEMASK	0x0FFFF	/* byte size mask for create part */

#define MT_LTYPE_PNO	0
#define MT_LTYPE_ATIME	1
#define MT_LTYPE_RTIME	2
#define MT_LTYPE_PTIME	3

struct mt_locate_type {
	char	type:3;
	char	immediate:1;
};
struct mt_locate_pno {
	char	type:3;
	char	immediate:1;
	int	pno;	/* BCD: rangeing from 001-799, oder 0BB, 0AA, 0EE */
};
struct mt_locate_time {
	char	type:3;
	char	immediate:1;
	int	hour;	/* BCD */
	int	minute;	/* BCD */
	int	second;	/* BCD */
	int	frame;	/* BCD */
};

union mt_locate {
	struct	mt_locate_type	locate_type;
	struct	mt_locate_pno	locate_pno;
	struct	mt_locate_time	locate_abstime;
	struct	mt_locate_time	locate_runtime;
	struct	mt_locate_time	locate_progtime;
};

struct mt_exver {
	int	mt_exver_uscsicmdrestricted:1;
	int	mt_exver_longerase:1;
	char	mt_exver_version[20];
};

/* 
 * options for MTIOCTOP calls ... numbers will work
 * they may NOT conflict with the others mt_op MT* numbers
 * in /usr/include/sys/mtio.h
 */
#define MTCRTPART	0x100	/* create partition */
#define MTDELPART	0x101	/* delete partition */
#define MTPARTTO	0x102	/* switch to part <arg> */
#define MTGETPART	0x103
#define MTSCOMP		0x104	/* enable/disable Compression */
#define MTSDECOMP	0x105	/* enable/disable decompression */
#define MTGCOMP		0x106	/* get compression status */
#define MTGDECOMP	0x107	/* get decompression status */

/* direct ioctl. numbers
 * BEWARE, for they may not conflict with other MTIO* in 
 * /usr/include/sys/mtio.h
 */
#ifdef sun
#define MTIOQLPAGE	0x6D10	/* Query Log Page, struct below is passed */
#define MTIOQMPAGE	0x6D11	/* Query Mode Page, struct below is passed */
#define MTIOSMPAGE	0x6D15	/* Set Mode Page, struct below is passed */
#define MTIOINQUIRY	0x6D12	/* Query Mode Page, struct below is passed */
#define MTIOEXVER	0x6D1A	/* extended version information for st */

/* audio mt calls */

#define MTIOLOCATE	0x6D13	/* AUDIO:locate to position in passed struct* */
#define MTIOREADPOS	0x6D14	/* AUDIO:get subinfo in passed struct* */

#define MTIOABORT	0x6D17	/*abort last scsi command (send abort message)*/
#define MTIORESET	0x6D18	/*reset scsi */
#define MTSETAUDIO	0x6D19	/*set audio call. not used by user software */
#endif

#ifdef linux
/* need to adhere to the _IOC specs here... (should this on Sun too) */
#define MTIOLOCATE	_IOW('m',0x80,union mt_locate) 
#define MTIOREADPOS	_IOC(_IOC_READ,'m',0x81,20) /* 20 bytes */
/* missing: */
/* MTIOQLPAGE
 * MTIOQMPAGE
 * MTIOSMPAGE
 * MTIOINQUIRY
 * MTIOABORT
 * MTIORESET
 * MTIOEXVER
 */
#endif

#if defined(sun) && defined(_KERNEL)

#define ST_IN_AUDIO (un->un_density_known && un->un_dp->densities[un->un_curdens]==0x80)

#endif


#define bcd2l(x) (((x)&0xf)+(((x)&0xf0)>>4)*10+(((x)&0xf00)>>8)*100+(((x)&0xf000)>>12)*1000)
#define l2bcd(x) (((x)%10)+(((x)/10)%10)*0x10+(((x)/100)%10)*0x100+(((x)/1000)%10)*0x1000)
