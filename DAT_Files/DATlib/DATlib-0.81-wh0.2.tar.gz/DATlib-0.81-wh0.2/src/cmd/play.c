/* $Id: play.c,v 1.2 1997/08/06 14:54:01 msmeissn Exp $
 *
 * $Log: play.c,v $
 * Revision 1.2  1997/08/06 14:54:01  msmeissn
 * +usage
 *
 * Revision 1.1  1997/03/16 20:27:25  msmeissn
 * Initial revision
 *
 *
 * play.c: Simple demo program to play a DAT-audio track to /dev/audio
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/fcntl.h>

#include "dataudiolib.h"
#include "xaudio.h"
#include "audio_filehdr.h"


int
main(int argc,char **argv) {
	int	fd = fileno(stdin);
	int afd = audio_open(O_WRONLY);
	unsigned char	buffer[2048];
	Audio_filehdr fhd;
	int	pos,res;

	
	read(fd,&fhd,sizeof(fhd));
	if (!memcmp(&(fhd.magic),".snd",4)) {
		fprintf(stderr,"found header:\n");
		fprintf(stderr,"\tsamplerate:%d\n",fhd.sample_rate);
		fprintf(stderr,"\tchannels:%d\n",fhd.channels);
		fprintf(stderr,"\tencoding:%d\n",fhd.encoding);
		switch (fhd.encoding) {
		case AUDIO_FILE_ENCODING_LINEAR_16:
			audio_change_attribs(afd,fhd.sample_rate,16,fhd.channels-1);
			break;
		default:
			fprintf(stderr,"Unknown encoding: %d\n",fhd.encoding);
			exit(1);
		}
	}
	audio_change_attribs(afd,44100,16,1);
	pos=0;
	while ((res=read(fd,buffer,2048))>0) {
		int	i;

		fprintf(stderr,"at %d\n",pos);
		pos+=res;

/*		for (i=0;i<res;i+=2) {
			unsigned char tmp = buffer[i+1];

			buffer[i+1] = buffer[i];
			buffer[i] = tmp;
		}
*/
		audio_write(afd,buffer,res);
	}
	audio_close(afd);
}
