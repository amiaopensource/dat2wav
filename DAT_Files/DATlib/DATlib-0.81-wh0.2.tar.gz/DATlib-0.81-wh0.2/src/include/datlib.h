/*
 * DATlib   Copyright (c) 1995-1996 Marcus Meissner &
 *          Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *          All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Marcus Meissner
 *    at the Friedrich-Alexander Universitaet Erlangen-Nuernberg (FAU), IMMD4
 *
 * 4. The name of the University or the author may not be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND THE AUTHOR ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* stub .h file ... prototypes will go here */
#ifdef __DATLIB_MAIN_C
#define EXTERN
#else
#define EXTERN extern
#endif

#ifndef _BIT_FIELDS_HTOL
#define _BIT_FIELDS_HTOL
#endif

#define SCMD_LOG_SENSE LOG_SENSE_CMD

/* generic define. damits schneller geht. */
#define RETURN(x) return ((x<0)?((errno=-x),-1):x)

struct datlib_functions {
	char	*name;	/* name of access device */
	int	(*get_version)(int fd,char *inqbuf,int inqsize);
	int	(*create_partition)(int fd,int size,int size_kind);
	int	(*delete_partition)(int fd);
	int	(*switch_active_partition)(int fd,int targetpart);
	int	(*query_active_partition)(int fd);
	int	(*set_compression)(int fd,int comptype);
	int	(*set_decompression)(int fd,int decomptype);
	int	(*query_compression)(int fd);
	int	(*query_decompression)(int fd);
	int	(*get_log_page)(int fd,int nr,unsigned char *logpage,int logsize);
	int	(*get_mode_page)(int fd,int nr,unsigned char *modepage,int modesize);
	int	(*set_mode_page)(int fd,unsigned char *modepage,int modesize);
	int	(*get_inquiry)(int fd,unsigned char *inqbuf,int inqsize);
	int	(*request_sense)(int fd,unsigned char *inqbuf,int inqsize);
	int	(*get_inquiry_extended)(int fd,int page,unsigned char *inqbuf,int inqsize);
	int	(*read_buffer)(int fd,int memid,unsigned long memoff,unsigned char *buf,int size);
	/* usw. */
};
struct datlib_access_kinds {
	char    *name;
	struct  datlib_functions        *(*init)(int fd);
};


EXTERN int
datlib_init(int fd,char *method);
/*
 *	initialisiert interne strukturen usw.
 *	uebergeben wird ein fd auf das tapedevice
 *	return 0 fuer success, -1 fuer failure, errno set.
 */

EXTERN int
datlib_create_partition(int fd,int size,int size_kind);
/*
 *	kreiert eine zweite partition.
 *	uebergeben wird fd auf TAPEdevice, size in 'size_kind' einheiten
 *	SIZE_BYTE,SIZE_KBYTE,SIZE_MBYTE
 *	return 0 fuer success, -1+errno fuer fehler.
 */

EXTERN int
datlib_delete_partition(int fd);
/* 
 *	removed die zweite partition
 *	rest wie oben
 */
EXTERN int
datlib_switch_active_partition(int fd,int targpart);
/*
 * 	schaltet auf targpart um.
 *	rest wie oben.
 *	return neue aktive partition. oder -1+errno fuer fehler
 */
EXTERN int
datlib_query_active_partition(int fd);
/*	returned die aktuelle partition oder -1+errno bei fehler*/

EXTERN int
datlib_set_compression(int fd,int comptype);
/*	setzt compression auf comptype. 0 fuer abschalten.*/

EXTERN int
datlib_set_decompression(int fd,int decomptype);
/*	setzt compression auf comptype. 0 fuer abschalten.*/

EXTERN int
datlib_query_compression(int fd);
/*	compression type wird returned, 0 fuer keine comp, -1+errno fehler*/

EXTERN int
datlib_query_decompression(int fd);
/*	decompression type wird returned, 0 fuer keine decomp, -1+errno fehler*/

EXTERN int
datlib_get_log_page(int fd,int nr,unsigned char*logpage,int logsize);
/*
 *	returned die logpage in *logpage bis maximal logsize.
 *	aktuelle laenge wird returned, -1+errno fuer fehler
 */
EXTERN int
datlib_get_mode_page(int fd,int nr,unsigned char *modepage,int modesize);
/*
 *	returned die modepage in *modepage bis maximal modesize.
 *	aktuelle laenge wird returned, -1+errno fuer fehler
 */
EXTERN int
datlib_set_mode_page(int fd,unsigned char *modepage,int modesize);
/*
 *	setzt die modepage in modepage bis modesize, -1+errno fuer fehler
 */
EXTERN int
datlib_request_sense(int fd,char *inqbuf,int inqsize);
/*
 *	returns the result of a request sense
 */
EXTERN int
datlib_get_inquiry(int fd,unsigned char *inqbuf,int inqsize);
/*
 *	returns the result of INQUIRY in inqbuf, up to inqsize
 *	-1&errno on failure
 *    -1&errno on failure
 */

EXTERN int
datlib_get_inquiry_extended(int fd,int page,unsigned char *inqbuf,int inqsize);
/*
 *    returns the result of INQUIRY in inqbuf, up to inqsize
 *    -1&errno on failure
 */

EXTERN int
datlib_read_buffer(int fd,int memid,unsigned long memoff, unsigned char *buf,int size);
/*
 *    returns the result of READ BUFFER in buf, up to size
 */
EXTERN int
datlib_get_version(int fd,char *inqbuf,int inqsize);
/*
 *	returns the version of datlib
 */

EXTERN int datlib_get_density(int fd);
EXTERN int datlib_set_density(int fd,int density);

#define SIZE_BYTE	0
#define	SIZE_KBYTE	1
#define SIZE_MBYTE	2

/* return all access methods to the lowlevel scsi/kernel interface 
 * in a NULL terminated list of strings.
 */
EXTERN char**
datlib_get_methods();
